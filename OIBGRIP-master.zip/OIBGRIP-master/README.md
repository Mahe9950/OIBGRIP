# OIBGRIP
Web Development internship project given by Oasis Infobyte (Level 2)

Task 1: calculator 

Tech stacks used: HTML CSS JAVASCRIPT



Task 2: Tribute page 

Teck stacks used: HTML CSS




Task 3: ToDo list

Teck stacks used: HTML CSS JAVASCRIPT
